authy-open-vpn
==============

Authy Open VPN Two-Factor Authentication

Basic Instruction to create the .deb
====================================
* Create the .tar.gz of the code
* dpkg-buildpackage -rfakeroot
